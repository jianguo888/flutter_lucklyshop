class Config{
  static String domain="https://jd.itying.com/";
}