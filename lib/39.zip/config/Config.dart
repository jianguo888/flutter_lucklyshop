class Config{
  static String domain="http://jd.itying.com/";
}